He hecho el ejercicio 5 al completo
He hecho modificaciones para que se salven los registros A y B en un cambio de contexto (cambio anotado con "CAMBIO HECHO EN LA V2")

No he podido terminar el apartado a del ejercicio 6


Aprovecho para recordar lo de ONEO para el practico del viernes 12