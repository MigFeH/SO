He hecho el ejercicio 10, 11 y 12 sin tener éste ultimo acabado

