Todos los ejercicios hasta el número 5 han sido completados.

En el ejercicio 5 tuve ciertas complicaciones a la hora de hacerlo porque creía que no tenía bien hecho el caso en el que
el fichero a ejecutar no existía porque al ejecutar el Simulador pasandole un fichero que no existía pues se me generaba
un bucle infinito pensando que había hecho algo mal.
Después de unas cuantas depuraciones y perderme en el código mientras depuraba, logré descubrir que el bucle infinito era
el SIP que se ejecutaba sin llegar a la instrucción HALT.

El bucle infinito no aparece si, además de pasar el programa que no existe le pasas un programa que sí existe.
De todas formas, en el caso en el que le pasas solo el programa que no existe y en el que no pasas solo eso, la implementación
del ejercicio cumple su función, asi que yo creo que está bien hecho.

Para el resto de ejercicios anteriores tuve pocos problemas pero todos fueron por perderme entre el código.