He hecho desde el ejercicio 1 hasta el 4 incluido.

Cuando se quiere comprobar si se muestra el mensaje de "invalid processor state" con la instruccion OS se corta la salida del tick en la que se llama a dicha instrucción.
Para comprobar que se muestra ese mensaje lo he hecho con IRET
